# quantuMon
OSX menubar system monitor app with the power of Electorn and the beauty Material Design.


## Build

```
$ npm install
$ grunt sass
$ npm run build
```

## Run
```
$ npm install
$ grunt sass
$ npm start
```


## Screenshot

![screen_1](screen_1.png)